def maskify(mobile_number):
    if len(mobile_number) <= 3:
        return mobile_number
    else:
        masked_digits = '#' * (len(mobile_number) - 3)
        last_three_digits = mobile_number[-3:]
        return masked_digits + last_three_digits


mobile_number = "9988776655"
print(maskify(mobile_number))