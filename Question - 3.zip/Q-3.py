class Person:
    def __init__(self):
        self.name = None
        self.age = None
        self.mobile = None

    def set_values(self):
        self.name = input("Enter name: ")
        self.age = input("Enter age: ")
        self.mobile = input("Enter mobile number: ")

    def get_values(self):
        print("Name:", self.name)
        print("Age:", self.age)
        print("Mobile:", self.mobile)

person = Person()
person.set_values()

print("\nDetails of the person:")
person.get_values()