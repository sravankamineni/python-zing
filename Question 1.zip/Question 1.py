def is_valid_decimal(input_str):
    try:
        int(input_str)
        return True
    except ValueError:
        return False

def is_valid_hexadecimal(input_str):
    valid_chars = set("0123456789ABCDEFabcdef")
    return all(char in valid_chars for char in input_str)

def decimal_to_hexadecimal(decimal):
    hexadecimal_digits = "0123456789ABCDEF"
    if decimal == 0:
        return "0"
    hexadecimal = ""
    while decimal > 0:
        remainder = decimal % 16
        hexadecimal = hexadecimal_digits[remainder] + hexadecimal
        decimal //= 16
    return hexadecimal

def hexadecimal_to_decimal(hexadecimal):
    hexadecimal = hexadecimal.upper()
    decimal = 0
    hexadecimal_digits = "0123456789ABCDEF"
    for digit in hexadecimal:
        decimal = 16 * decimal + hexadecimal_digits.index(digit)
    return decimal

def main():
    choice = input("Enter 'D' for Decimal to Hexadecimal conversion or 'H' for Hexadecimal to Decimal conversion: ").upper()
    
    if choice == 'D':
        decimal_input = input("Enter a decimal number: ")
        if is_valid_decimal(decimal_input):
            decimal_input = int(decimal_input)
            hexadecimal_output = decimal_to_hexadecimal(decimal_input)
            print("Hexadecimal:", hexadecimal_output)
        else:
            print("Invalid input! Please enter a valid decimal number.")
    
    elif choice == 'H':
        hexadecimal_input = input("Enter a hexadecimal number: ")
        if is_valid_hexadecimal(hexadecimal_input):
            decimal_output = hexadecimal_to_decimal(hexadecimal_input)
            print("Decimal:", decimal_output)
        else:
            print("Invalid input! Please enter a valid hexadecimal number.")
    
    else:
        print("Invalid choice! Please enter 'D' or 'H'.")

if __name__ == "__main__":
    main()