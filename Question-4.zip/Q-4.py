import re

def validate_password(password):
    if len(password) < 8:
        return False, "Password must have at least 8 characters."
    
    if not re.search("[a-z]", password):
        return False, "Password must contain at least one lowercase letter."
    
    if not re.search("[A-Z]", password):
        return False, "Password must contain at least one uppercase letter."
    
    if not re.search("[0-9]", password):
        return False, "Password must contain at least one digit."
    
    if not re.search("[_@$]", password):
        return False, "Password must contain at least one special character (_@$)."
    
    return True, "Password is safe."

password = input("Enter password: ")
is_valid, message = validate_password(password)
print(message)